export { getLang } from './getLang';
export { getTemplate } from './getTemplate';
export { getProjectName } from './getProjectName';
export { getDirectoryName } from './getDirectoryName';
