## v2.1.0

- Перевели шаблоны на `@vkontakte/vkui@7`, обновили `@vkontakte/vk-mini-apps-router`, `@vkontakte/icons` и `@vkontakte/vk-tunnel`.

## v2.0.10

- Добавили настройки vite для hot-reload @vkontakte/vk-tunnel.

## v2.0.7

- Обновили версию и скрипт запуска утилиты @vkontakte/vk-tunnel.

## v2.0.6

- Добавили в devDependencies обновленный @vkontakte/vk-tunnel.

## v2.0.5

- Исправили ошибки сборки для архива odr.

## v2.0.4

- Обновили сборку, чтобы полученный при запуске [vk-miniapps-deploy](https://github.com/VKCOM/vk-miniapps-deploy) архив мог использоваться в odr.

## v2.0.3

- 26.02.2024 - Публикация. Описание можно найти в [документации](https://dev.vk.ru/ru/mini-apps/getting-started/create-vk-mini-app).
