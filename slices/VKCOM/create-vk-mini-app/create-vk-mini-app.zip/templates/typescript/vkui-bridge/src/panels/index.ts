export { Persik } from './Persik';
export { Home } from './Home';

export type { PersikProps } from './Persik';
export type { HomeProps } from './Home';
