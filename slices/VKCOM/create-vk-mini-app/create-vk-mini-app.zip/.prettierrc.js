module.exports = require('@vkontakte/prettier-config').createConfig();
